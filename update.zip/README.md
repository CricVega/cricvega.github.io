# CricVega – Live Cricket Score

Developed by **Pawan Verma · PAWANGAMINGSTUDIO**

Website: https://cricvega.github.io/ — free live cricket scores, ball-by-ball commentary, scorecards, schedules & news. No login, no app.

## 🔴 Live & upcoming matches (auto-updated)

- [India Under-19s vs Australia Under-19s — Preview](https://cricvega.github.io/match/1535685-india-under-19s-vs-australia-under-19s)
- [Mah-e-Par Stars vs Hindukush Strikers — Preview](https://cricvega.github.io/match/1551344-mah-e-par-stars-vs-hindukush-strikers)
- [Victoria vs South Australia — Preview](https://cricvega.github.io/match/1544864-victoria-vs-south-australia)
- [Zimbabwe Women vs West Indies Women — Preview](https://cricvega.github.io/match/1554980-zimbabwe-women-vs-west-indies-women)
- [South Western Districts vs Lions — Preview](https://cricvega.github.io/match/1551857-south-western-districts-vs-lions)
- [Knights vs KwaZulu-Natal Inland — Preview](https://cricvega.github.io/match/1551855-knights-vs-kwazulu-natal-inland)
- [Titans vs South Africa Emerging Players — Preview](https://cricvega.github.io/match/1551856-titans-vs-south-africa-emerging-players)

## Recent results


## Series

- [Live Cricket](https://cricvega.github.io/series/-live-cricket)
