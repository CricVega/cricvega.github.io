# CricVega – Live Cricket Score

Developed by **Pawan Verma · PAWANGAMINGSTUDIO**

Website: https://cricvega.github.io/ — free live cricket scores, ball-by-ball commentary, scorecards, schedules & news. No login, no app.

## 🔴 Live & upcoming matches (auto-updated)

- [India Under-19s vs Australia Under-19s — Preview](https://cricvega.github.io/match/1535685-india-under-19s-vs-australia-under-19s)
- [India A vs Australia A — Preview](https://cricvega.github.io/match/1535674-india-a-vs-australia-a)
- [Mah-e-Par Stars vs Hindukush Strikers — Preview](https://cricvega.github.io/match/1551344-mah-e-par-stars-vs-hindukush-strikers)
- [United States of America vs United Arab Emirates — Preview](https://cricvega.github.io/match/1554410-united-states-of-america-vs-united-arab-emirates)
- [India vs West Indies — Preview](https://cricvega.github.io/match/1529230-india-vs-west-indies)
- [Western Province vs Easterns — Preview](https://cricvega.github.io/match/1551854-western-province-vs-easterns)

## Recent results


## Series

- [Live Cricket](https://cricvega.github.io/series/ci-live-cricket)
